Mars-mönkijöiden reitinhakualgoritmit ja visuaalinen paikannus
##############################################################
